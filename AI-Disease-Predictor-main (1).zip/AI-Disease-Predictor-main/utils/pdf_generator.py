# utils/pdf_generator.py
from fpdf import FPDF
import datetime
import os

class MedicalPDF(FPDF):
    def header(self):
        self.set_font("helvetica", "B", 18)
        self.cell(0, 10, "AI Multi-Disease Diagnostic Report", ln=True, align="C")
        self.set_font("helvetica", "I", 10)
        self.cell(0, 8, f"Generated on: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", ln=True, align="C")
        self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font("helvetica", "I", 8)
        self.cell(0, 10, f"Page {self.page_no()} | Disclaimer: AI-generated clinical aid. Not a substitute for professional diagnosis.", align="C")

def generate_report(name, input_dict, results, high_risk_flags, shap_image_path=None):
    pdf = MedicalPDF()
    pdf.add_page()
    
    # --- Section 1: Patient Profile ---
    pdf.set_font("helvetica", "B", 14)
    pdf.set_fill_color(200, 220, 255)
    pdf.cell(0, 10, " 1. Patient Profile & Primary Vitals", ln=True, fill=True)
    pdf.ln(3)
    
    patient_name = name if name else "Not Provided"
    pdf.set_font("helvetica", "B", 11)
    pdf.cell(0, 8, f"Patient Name: {patient_name}", ln=True)
    pdf.ln(2)
    
    pdf.set_fill_color(240, 240, 240)
    pdf.cell(95, 8, "Clinical Metric", border=1, fill=True)
    pdf.cell(95, 8, "Recorded Value", border=1, ln=True, fill=True)
    
    pdf.set_font("helvetica", "", 11)
    for key, value in input_dict.items():
        pdf.cell(95, 8, f" {key}", border=1)
        pdf.cell(95, 8, f" {value}", border=1, ln=True)
    pdf.ln(8)
    
    # --- Section 2: Unified Multi-Disease Assessment ---
    pdf.set_font("helvetica", "B", 14)
    pdf.set_fill_color(200, 220, 255)
    pdf.cell(0, 10, " 2. AI Multi-Disease Assessment", ln=True, fill=True)
    pdf.ln(3)
    
    pdf.set_font("helvetica", "B", 11)
    pdf.cell(95, 8, "Diagnostic Module", border=1, fill=True)
    pdf.cell(95, 8, "Risk Status", border=1, ln=True, fill=True)
    
    # List all diseases dynamically
    module_names = {'diabetes': 'Diabetes', 'heart': 'Heart Disease', 'liver': 'Liver Disease', 'kidney': 'Kidney Failure'}
    for key, res in results.items():
        display_name = module_names[key]
        prob = res['probability']
        
        pdf.set_font("helvetica", "B", 11)
        pdf.cell(95, 8, f" {display_name}", border=1)
        
        if res['prediction'] == 1:
            pdf.set_text_color(220, 0, 0)
            status = f"HIGH RISK ({prob:.1%})"
        else:
            pdf.set_text_color(0, 128, 0)
            status = f"LOW RISK ({prob:.1%})"
            
        pdf.cell(95, 8, f" {status}", border=1, ln=True)
        pdf.set_text_color(0, 0, 0) # Reset color
        
    pdf.ln(8)
    
    # --- Section 3: Explainability (SHAP Chart) ---
    if high_risk_flags and shap_image_path and os.path.exists(shap_image_path):
        if pdf.get_y() > 200: 
            pdf.add_page()
            
        pdf.set_font("helvetica", "B", 14)
        pdf.set_fill_color(200, 220, 255)
        pdf.cell(0, 10, " 3. Primary Risk Rationale (Feature Impact)", ln=True, fill=True)
        pdf.set_font("helvetica", "I", 10)
        pdf.cell(0, 8, f"The chart below explains the vital signs driving the {high_risk_flags[0][0]} alert.", ln=True)
        
        pdf.image(shap_image_path, x=20, w=160) 
        pdf.ln(5)

    return bytes(pdf.output())